"use client";
import { useState, useEffect, Suspense } from "react";
import { Moon, Sun } from "lucide-react";
import { toast } from "sonner";
import { AuthPageProps, AuthView } from "../../lib/types";
import { LeftPanel } from "../../components/auth/LeftPanel";
import { MainView } from "../../components/auth/MainView";
import { TwoFAView } from "../../components/auth/TwoFAView";
import { ForgotPasswordView } from "../../components/auth/ForgotPasswordView";
import { ResetPasswordView } from "../../components/auth/ResetPasswordView";
import { Setup2FAView } from "../../components/auth/Setup2FAView";
import { authService } from "../service/authservice";
import { useSearchParams, useRouter, usePathname } from "next/navigation";

interface ExtendedAuthPageProps extends AuthPageProps {
          hideSignUp?: boolean;
}

function AuthPageContent(props: ExtendedAuthPageProps) {
          const {
                    appName = "MarketHub",
                    appRole = "User",
                    leftPanelTitle = "Welcome to MarketHub",
                    leftPanelSubtitle = "The premium B2B marketplace platform.",
                    leftPanelFeatures = [],
                    googleClientId,
                    hideSignUp = false,
          } = props;

          const [isLoading, setIsLoading] = useState(false);
          const [isDarkMode, setIsDarkMode] = useState(false);
          const [tempUserId, setTempUserId] = useState<string | null>(null);
          const [otpCode, setOtpCode] = useState("");
          const [otpauthUrl, setOtpauthUrl] = useState<string | null>(null);

          const router = useRouter();
          const pathname = usePathname();
          const searchParams = useSearchParams();

          const urlToken = searchParams?.get("token");
          const viewParam = searchParams?.get("view") as AuthView | null;
          const tabParam = searchParams?.get("tab") || "signin";

          const activeView: AuthView = urlToken ? 'reset' : (viewParam || 'main');

          const changeView = (newView: AuthView) => {
                    const params = new URLSearchParams(searchParams?.toString() || "");
                    if (newView === 'main') {
                              params.delete('view');
                    } else {
                              params.set('view', newView);
                    }
                    if (newView !== 'reset') params.delete('token');
                    router.push(`${pathname}?${params.toString()}`, { scroll: false });
          };

          const changeTab = (newTab: string) => {
                    const params = new URLSearchParams(searchParams?.toString() || "");
                    if (newTab === 'signin') {
                              params.delete('tab');
                    } else {
                              params.set('tab', newTab);
                    }
                    router.push(`${pathname}?${params.toString()}`, { scroll: false });
          };

          useEffect(() => {
                    if (urlToken) {
                              toast.info("Please set your new password.");
                    }
          }, [urlToken]);

          const handleSetup2FA = async (userId: string) => {
                    setIsLoading(true);
                    try {
                              const response = await authService.setup2FA(userId);
                              setOtpauthUrl(response.otpauth_url);
                              setTempUserId(userId);
                              changeView('setup-2fa');
                    } catch (error: any) {
                              toast.error(error);
                    } finally {
                              setIsLoading(false);
                    }
          };

          return (
                    <div className={`${isDarkMode ? "dark" : ""} w-full h-screen font-sans`}>
                              <main className="grid lg:grid-cols-12 h-screen w-full overflow-hidden bg-background text-foreground transition-colors duration-300">
                                        <LeftPanel
                                                  appName={appName}
                                                  appRole={appRole!}
                                                  leftPanelTitle={leftPanelTitle!}
                                                  leftPanelSubtitle={leftPanelSubtitle!}
                                                  leftPanelFeatures={leftPanelFeatures!}
                                        />
                                        <section className="relative flex flex-col p-6 lg:p-12 w-full h-full overflow-y-auto scrollbar-hide lg:col-span-7">
                                                  <button
                                                            onClick={() => setIsDarkMode(!isDarkMode)}
                                                            className="absolute top-4 right-4 lg:top-8 lg:right-8 p-3 rounded-full bg-muted text-muted-foreground hover:text-foreground hover:bg-muted/80 transition-all cursor-pointer z-50"
                                                  >
                                                            {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                                                  </button>

                                                  <div className="w-full max-w-[420px] my-auto mx-auto pb-10 transition-all duration-500 ease-in-out">
                                                            {activeView === 'main' && (
                                                                      <MainView
                                                                                appRole={appRole!}
                                                                                isLoading={isLoading}
                                                                                setIsLoading={setIsLoading}
                                                                                setView={changeView}
                                                                                setTempUserId={setTempUserId}
                                                                                googleClientId={googleClientId} // 🟢 Passes Client ID down
                                                                                onSetup2FA={handleSetup2FA}
                                                                                tabParam={tabParam}
                                                                                changeTab={changeTab}
                                                                                hideSignUp={hideSignUp}
                                                                      />
                                                            )}
                                                            {activeView === 'forgot' && (
                                                                      <ForgotPasswordView isLoading={isLoading} setIsLoading={setIsLoading} setView={changeView} />
                                                            )}
                                                            {activeView === 'reset' && (
                                                                      <ResetPasswordView isLoading={isLoading} setIsLoading={setIsLoading} setView={changeView} />
                                                            )}
                                                            {activeView === '2fa' && (
                                                                      <TwoFAView
                                                                                tempUserId={tempUserId}
                                                                                otpCode={otpCode}
                                                                                setOtpCode={setOtpCode}
                                                                                isLoading={isLoading}
                                                                                setIsLoading={setIsLoading}
                                                                                setView={changeView}
                                                                                onSuccess={() => router.push('/dashboard')}
                                                                      />
                                                            )}
                                                            {activeView === 'setup-2fa' && (
                                                                      <Setup2FAView
                                                                                tempUserId={tempUserId}
                                                                                otpCode={otpCode}
                                                                                setOtpCode={setOtpCode}
                                                                                otpauthUrl={otpauthUrl}
                                                                                isLoading={isLoading}
                                                                                setIsLoading={setIsLoading}
                                                                                setView={changeView}
                                                                                onSuccess={() => router.push('/dashboard')}
                                                                      />
                                                            )}
                                                  </div>
                                        </section>
                              </main>
                    </div>
          );
}

// 🟢 Simplifed Wrapper (No Google Auth Provider needed at top level anymore)
export default function AuthPage(props: ExtendedAuthPageProps) {
          return (
                    <Suspense fallback={<div className="flex h-screen w-full items-center justify-center">Loading MarketHub...</div>}>
                              <AuthPageContent {...props} />
                    </Suspense>
          );
}