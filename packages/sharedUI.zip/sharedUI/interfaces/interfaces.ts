import { AuthView } from "@/lib/types";
import type { LucideIcon } from "lucide-react";

export interface BaseAuthProps {
          apiUrl: string; // 🟢 Required in all forms
          isLoading: boolean;
          setIsLoading: (v: boolean) => void;
          setView: (v: AuthView) => void;
}

export interface Base2FAProps extends BaseAuthProps {
          tempUserId: string | null;
          otpCode: string;
          setOtpCode: (v: string) => void;
          onSuccess: () => void;
}


export interface ForgotPasswordViewProps extends BaseAuthProps { }

export interface ResetPasswordViewProps extends BaseAuthProps { }

export interface LeftPanelProps {
          appName: string;
          appRole: string;
          leftPanelTitle: string | React.ReactNode;
          leftPanelSubtitle: string;
          leftPanelFeatures: { icon: LucideIcon; text: string }[];
}

export interface MainViewProps extends BaseAuthProps {
          appRole: string;
          setTempUserId: (id: string) => void;
          googleClientId?: string;
          googleRedirectUri?: string; // 🟢 Added here
          onSetup2FA: (userId: string) => void;
          tabParam: string;
          changeTab: (v: string) => void;
          hideSignUp?: boolean;
}

export interface SignInFormProps extends BaseAuthProps {
          setTempUserId: (id: string) => void;
          onSetup2FA: (userId: string) => void;
}

export interface SignUpFormProps extends BaseAuthProps {
          appRole: string;
          changeTab: (tab: string) => void;
}

export interface TwoFAViewProps extends Base2FAProps { }

export interface Setup2FAViewProps extends Base2FAProps {
          otpauthUrl: string | null; // Sirf yeh line Setup mein extra hai
}