import type { LucideIcon } from "lucide-react";

export type AuthView = 'main' | '2fa' | 'forgot' | 'reset' | 'setup-2fa';

export interface AuthPageProps {
          apiUrl: string; // 🟢 Required from App
          appName?: string;
          appRole?: string;
          logoSrc?: string;
          googleClientId?: string;
          googleRedirectUri?: string; // 🟢 Pass redirect URI dynamically
          hideSignUp?: boolean;
          leftPanelTitle?: string | React.ReactNode;
          leftPanelSubtitle?: string;
          leftPanelFeatures?: { icon: LucideIcon; text: string }[];
}