"use client";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";
import { SignInForm } from "./SignInForm";
import { SignUpForm } from "./SignUpForm";
import { MainViewProps } from "@/interfaces/interfaces";
import { GoogleOAuthProvider, useGoogleLogin } from "@react-oauth/google";
import { toast } from "sonner";
import { getAuthService } from "../../auth/service/authservice";

// 🟢 Receive apiUrl and redirectUri
function GoogleSignInButton({ appRole, apiUrl, redirectUri }: { appRole: string; apiUrl: string; redirectUri?: string }) {
          const [isGoogleLoading, setIsGoogleLoading] = useState(false);
          const authService = getAuthService(apiUrl); // 🟢 Initialize dynamically

          const loginWithGoogle = useGoogleLogin({
                    flow: "auth-code",
                    redirect_uri: redirectUri, // 🟢 Dynamic Redirect URI
                    onSuccess: async ({ code }) => {
                              setIsGoogleLoading(true);
                              try {
                                        const response = await authService.googleAuth(code, appRole.toLowerCase());
                                        localStorage.setItem("marketHub_token", response.token);
                                        toast.success(`Welcome, ${response.user?.username || "User"}!`);
                                        window.location.href = "/dashboard";
                              } catch (error: any) {
                                        toast.error(error?.message || "Google Sign-In failed.");
                              } finally {
                                        setIsGoogleLoading(false);
                              }
                    },
                    onError: () => toast.error("Google Sign-In failed."),
          });

          return (
                    <Button
                              type="button"
                              variant="outline"
                              onClick={() => loginWithGoogle()}
                              disabled={isGoogleLoading}
                              className="h-14 rounded-2xl bg-background hover:bg-muted/50 transition-colors w-full cursor-pointer text-base"
                    >
                              <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24">
                                        {/* SVG paths omitted for brevity */}
                              </svg>
                              {isGoogleLoading ? "Connecting..." : "Continue with Google"}
                    </Button>
          );
}

export function MainView(props: MainViewProps) {
          const {
                    appRole, isLoading, setIsLoading, setView, setTempUserId, googleClientId, googleRedirectUri,
                    onSetup2FA, tabParam, changeTab, hideSignUp, apiUrl
          } = props;

          return (
                    <div className="animate-in fade-in zoom-in-95 duration-300 pt-8 lg:pt-5 flex flex-col justify-center items-start">
                              {/* Tabs code... */}
                              <TabsContent value="signin" className="space-y-6 w-full">
                                        {/* 🟢 Pass apiUrl down */}
                                        <SignInForm apiUrl={apiUrl} isLoading={isLoading} setIsLoading={setIsLoading} setView={setView} setTempUserId={setTempUserId} onSetup2FA={onSetup2FA} />
                              </TabsContent>

                              {!hideSignUp && (
                                        <TabsContent value="signup" className="space-y-6 w-full">
                                                  <SignUpForm apiUrl={apiUrl} appRole={appRole} isLoading={isLoading} setIsLoading={setIsLoading} setView={setView} changeTab={changeTab} />
                                        </TabsContent>
                              )}

                              {googleClientId && (
                                        <div className="mt-8 pt-8 border-t border-border text-center w-full">
                                                  <GoogleOAuthProvider clientId={googleClientId}>
                                                            {/* 🟢 Pass apiUrl and redirectUri */}
                                                            <GoogleSignInButton appRole={appRole} apiUrl={apiUrl} redirectUri={googleRedirectUri} />
                                                  </GoogleOAuthProvider>
                                        </div>
                              )}
                    </div>
          );
}