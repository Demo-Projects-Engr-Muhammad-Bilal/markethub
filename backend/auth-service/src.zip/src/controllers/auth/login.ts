import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';
import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';

const prisma = new PrismaClient();

export const login = async (req: Request, res: Response): Promise<any> => {
          try {
                    const { email, password } = req.body;

                    const user = await prisma.user.findUnique({ where: { email } });

                    if (!user || !user.password_hash) {
                              return res.status(400).json({ success: false, message: 'Invalid email or password' });
                    }

                    const isMatch = await bcrypt.compare(password, user.password_hash);
                    if (!isMatch) {
                              return res.status(400).json({ success: false, message: 'Invalid email or password' });
                    }

                    // 🛑 Status checks
                    if (user.status !== 'approved') {
                              if (user.status === 'pending') {
                                        return res.status(403).json({
                                                  success: false,
                                                  message: 'Your account is still pending. You can login once the Admin approves it.'
                                        });
                              }
                              if (user.status === 'rejected') {
                                        return res.status(403).json({
                                                  success: false,
                                                  message: 'Your account registration was rejected during verification.'
                                        });
                              }
                              if (user.status === 'blocked') {
                                        return res.status(403).json({
                                                  success: false,
                                                  message: 'Your account has been blocked due to policy violations.'
                                        });
                              }
                    }

                    // 🛑 Role-based 2FA logic
                    const rolesWith2FA = ['owner', 'admin', 'seller', 'dropshipper'];

                    if (rolesWith2FA.includes(user.role)) {
                              if (user.two_factor_enabled && user.two_factor_secret) {
                                        // ✅ 2FA already setup — verify karo
                                        return res.status(200).json({
                                                  success: true,
                                                  require2FA: true,
                                                  action: 'verify',
                                                  userId: user.id,
                                                  message: 'Two-Factor Authentication required. Please provide your OTP code.'
                                        });
                              } else {
                                        // ✅ 2FA setup nahi — pehle setup karo
                                        return res.status(200).json({
                                                  success: true,
                                                  require2FA: true,
                                                  action: 'setup',
                                                  userId: user.id,
                                                  message: 'Please setup Two-Factor Authentication first.'
                                        });
                              }
                    }

                    // ✅ Normal login — Customer (No 2FA)
                    const token = jwt.sign(
                              { id: user.id, role: user.role },
                              process.env.JWT_SECRET as string,
                              { expiresIn: '1d' }
                    );

                    return res.status(200).json({
                              success: true,
                              message: 'Login successful!',
                              token,
                              user: {
                                        id: user.id,
                                        username: user.username,
                                        email: user.email,
                                        role: user.role
                              }
                    });

          } catch (error) {
                    console.error("❌ Login Error:", error);
                    return res.status(500).json({ success: false, message: 'Internal Server Error' });
          }
};