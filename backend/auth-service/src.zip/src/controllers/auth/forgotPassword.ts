import { PrismaClient } from '@prisma/client';
import crypto from 'crypto';
import { Request, Response } from 'express';
import { sendResetEmail } from '../../utils/emailservice.js';

const prisma = new PrismaClient();

export const forgotPassword = async (req: Request, res: Response): Promise<any> => {
          try {
                    const { email } = req.body;

                    const user = await prisma.user.findUnique({ where: { email } });

                    if (!user) {
                              return res.status(200).json({
                                        success: true,
                                        message: 'If an account with that email exists, a reset token has been sent.'
                              });
                    }

                    const resetToken = crypto.randomBytes(32).toString('hex');
                    const resetTokenExpiry = new Date(Date.now() + 60 * 60 * 1000);

                    await prisma.user.update({
                              where: { email },
                              data: {
                                        reset_password_token: resetToken,
                                        reset_password_expires: resetTokenExpiry
                              }
                    });

                    // ✅ Token directly email mein bhejo (link nahi)
                    await sendResetEmail(email, resetToken);

                    return res.status(200).json({
                              success: true,
                              message: 'Password reset token has been sent to your email.'
                    });

          } catch (error) {
                    console.error("❌ Forgot Password Error:", error);
                    return res.status(500).json({ success: false, message: 'Internal Server Error' });
          }
};