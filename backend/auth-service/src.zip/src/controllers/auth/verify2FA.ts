import { PrismaClient } from '@prisma/client';
import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import speakeasy from 'speakeasy';

const prisma = new PrismaClient();

export const verify2FA = async (req: Request, res: Response): Promise<any> => {
          try {
                    const { userId, code } = req.body;

                    const user = await prisma.user.findUnique({ where: { id: userId } });
                    if (!user || !user.two_factor_secret) {
                              return res.status(400).json({ success: false, message: '2FA is not configured for this user.' });
                    }

                    // ✅ Real speakeasy verification
                    const verified = speakeasy.totp.verify({
                              secret: user.two_factor_secret,
                              encoding: 'base32',
                              token: code,
                              window: 1
                    });

                    if (!verified) {
                              return res.status(400).json({ success: false, message: 'Invalid 2FA authentication code.' });
                    }

                    const token = jwt.sign(
                              { id: user.id, role: user.role },
                              process.env.JWT_SECRET as string,
                              { expiresIn: '1d' }
                    );

                    return res.status(200).json({
                              success: true,
                              message: '2FA Verification successful! Login complete.',
                              token,
                              user: { id: user.id, username: user.username, email: user.email, role: user.role }
                    });
          } catch (error) {
                    console.error("❌ 2FA Verification Error:", error);
                    return res.status(500).json({ success: false, message: 'Internal Server Error' });
          }
};