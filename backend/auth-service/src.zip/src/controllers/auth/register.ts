import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';
import { Request, Response } from 'express';

const prisma = new PrismaClient();

export const register = async (req: Request, res: Response): Promise<any> => {
          try {
                    const { username, email, password, role, phone_number } = req.body;

                    const existingUser = await prisma.user.findUnique({ where: { email } });
                    if (existingUser) {
                              return res.status(400).json({ success: false, message: 'Email already exists!' });
                    }

                    const salt = await bcrypt.genSalt(10);
                    const password_hash = await bcrypt.hash(password, salt);

                    const initialStatus = (role === 'customer') ? 'approved' : 'pending';

                    const newUser = await prisma.user.create({
                              data: {
                                        username,
                                        email,
                                        password_hash,
                                        role: role || 'customer',
                                        phone_number,
                                        status: initialStatus
                              }
                    });

                    return res.status(201).json({
                              success: true,
                              message: role === 'customer'
                                        ? 'Account created successfully!'
                                        : 'Account registered! Waiting for admin approval.',
                              userId: newUser.id
                    });
          } catch (error) {
                    console.error("❌ Register Error:", error);
                    return res.status(500).json({ success: false, message: 'Internal Server Error' });
          }
};