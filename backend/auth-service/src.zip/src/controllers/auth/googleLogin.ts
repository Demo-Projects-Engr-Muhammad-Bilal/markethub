import { PrismaClient } from '@prisma/client';
import axios from 'axios';
import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';

const prisma = new PrismaClient();

export const googleLogin = async (req: Request, res: Response): Promise<any> => {
          try {
                    const { token, role } = req.body;

                    const googleResponse = await axios.get('https://www.googleapis.com/oauth2/v3/userinfo', {
                              headers: {
                                        Authorization: `Bearer ${token}`
                              }
                    });

                    const payload = googleResponse.data;

                    if (!payload || !payload.email) {
                              return res.status(400).json({ success: false, message: "Invalid Google Token" });
                    }

                    const { email, name } = payload;

                    let user = await prisma.user.findUnique({ where: { email } });

                    if (!user) {
                              user = await prisma.user.create({
                                        data: {
                                                  email,
                                                  username: name || "Google User",
                                                  auth_provider: "google",
                                                  role: role || "customer",
                                                  status: "approved"
                                        }
                              });
                    }

                    const jwtToken = jwt.sign(
                              { id: user.id, role: user.role },
                              process.env.JWT_SECRET || 'fallback_secret',
                              { expiresIn: '1d' }
                    );

                    return res.status(200).json({
                              success: true,
                              message: 'Google Sign-In successful!',
                              token: jwtToken,
                              user: { id: user.id, username: user.username, email: user.email, role: user.role }
                    });
          } catch (error: any) {
                    console.error("❌ Google Auth Error:", error?.response?.data || error.message);
                    return res.status(500).json({ success: false, message: 'Google Authentication Failed' });
          }
};