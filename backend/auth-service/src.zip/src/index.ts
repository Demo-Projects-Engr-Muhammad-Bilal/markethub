import dotenv from 'dotenv';
dotenv.config();

import express from 'express';
import type { Application } from "express";
import cors from 'cors';
import authRoutes from './routes/authRoutes.js';

const app: Application = express();

app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);

const PORT = process.env.PORT || 5001;

app.listen(PORT, () => {
          console.log(`🚀 MarketHub Auth Service is running on port ${PORT} (TypeScript)`);
});