import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export const sendResetEmail = async (toEmail: string, resetToken: string): Promise<void> => {
  const { error } = await resend.emails.send({
    from: 'onboarding@resend.dev',  // ✅ Free version ke liye — sirf apni registered email pe jayega
    to: toEmail,
    subject: 'Reset Your MarketHub Password',
    html: `
      <!DOCTYPE html>
      <html>
        <body style="margin:0;padding:0;background-color:#f4f4f5;font-family:sans-serif;">
          <table width="100%" cellpadding="0" cellspacing="0" style="padding:40px 0;">
            <tr>
              <td align="center">
                <table width="480" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);">

                  <!-- Header -->
                  <tr>
                    <td style="background:#09090b;padding:32px 40px;text-align:center;">
                      <h1 style="margin:0;color:#ffffff;font-size:22px;font-weight:600;">
                        Market<span style="color:#e11d48;">Hub</span>
                      </h1>
                    </td>
                  </tr>

                  <!-- Body -->
                  <tr>
                    <td style="padding:40px;">
                      <div style="text-align:center;margin-bottom:32px;">
                        <div style="display:inline-block;background:#fff1f2;border-radius:50%;width:64px;height:64px;line-height:64px;text-align:center;margin-bottom:16px;">
                          <span style="font-size:28px;">🔑</span>
                        </div>
                        <h2 style="margin:0 0 8px;color:#09090b;font-size:22px;font-weight:600;">Reset Your Password</h2>
                        <p style="margin:0;color:#71717a;font-size:14px;">We received a request to reset your MarketHub password.</p>
                      </div>

                      <p style="color:#3f3f46;font-size:14px;line-height:1.6;margin:0 0 24px;">
                        Use the token below to reset your password. Go to the login page, 
                        click <strong>"Forgot Password"</strong>, then enter this token along with your new password.
                        This token will expire in <strong>1 hour</strong>.
                      </p>

                      <!-- Token Box -->
                      <div style="background:#f4f4f5;border:2px dashed #e11d48;border-radius:12px;padding:20px;text-align:center;margin:24px 0;">
                        <p style="margin:0 0 8px;color:#71717a;font-size:12px;font-weight:500;text-transform:uppercase;letter-spacing:1px;">
                          Your Reset Token
                        </p>
                        <p style="margin:0;color:#09090b;font-size:18px;font-weight:700;letter-spacing:2px;word-break:break-all;font-family:monospace;">
                          ${resetToken}
                        </p>
                      </div>

                      <div style="background:#fff7ed;border-radius:10px;padding:16px;margin:24px 0;">
                        <p style="margin:0;color:#9a3412;font-size:13px;line-height:1.6;">
                          <strong>📋 Steps:</strong><br/>
                          1. Go to the login page<br/>
                          2. Click <strong>"Forgot Password"</strong><br/>
                          3. Enter your email and click Send<br/>
                          4. Paste this token and set your new password
                        </p>
                      </div>

                      <hr style="border:none;border-top:1px solid #f4f4f5;margin:32px 0;" />

                      <p style="color:#a1a1aa;font-size:12px;margin:0;line-height:1.6;">
                        If you didn't request a password reset, you can safely ignore this email.
                      </p>
                    </td>
                  </tr>

                  <!-- Footer -->
                  <tr>
                    <td style="background:#f4f4f5;padding:20px 40px;text-align:center;">
                      <p style="margin:0;color:#a1a1aa;font-size:12px;">© 2025 MarketHub. All rights reserved.</p>
                    </td>
                  </tr>

                </table>
              </td>
            </tr>
          </table>
        </body>
      </html>
    `
  });

  if (error) {
    console.error("❌ Resend Error:", error);
    throw new Error("Failed to send reset email.");
  }
};